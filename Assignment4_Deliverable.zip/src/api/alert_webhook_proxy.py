"""
scripts/alert_webhook_proxy.py
Lightweight Flask server that:
1. Receives alerts from Alertmanager (POST /alert)
2. Translates to GitHub Actions workflow_dispatch format
3. Triggers intelligent retraining CI/CD workflow

Deploy this as a small service in your cluster.
"""

import os
import json
import logging
import requests
from flask import Flask, request, jsonify

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)

GITHUB_TOKEN   = os.environ["GITHUB_TOKEN"]
GITHUB_REPO    = os.environ.get("GITHUB_REPO", "YOUR_ORG/fraud-detection")
WORKFLOW_FILE  = "fraud-detection-cicd.yml"
GITHUB_REF     = os.environ.get("GITHUB_REF", "main")
GITHUB_API     = f"https://api.github.com/repos/{GITHUB_REPO}/actions/workflows/{WORKFLOW_FILE}/dispatches"


def extract_alert_info(payload: dict) -> dict:
    """Extract relevant info from Alertmanager webhook payload."""
    alerts = payload.get("alerts", [])
    info = {
        "trigger_reason": "monitoring_alert",
        "current_recall": None,
        "drift_score": None,
    }

    for alert in alerts:
        name   = alert.get("labels", {}).get("alertname", "")
        status = alert.get("status", "")

        if status != "firing":
            continue

        if "Recall" in name:
            info["trigger_reason"] = "recall_drop"
            # Try to extract value from annotations
            val = alert.get("annotations", {}).get("value", "")
            if val:
                try:
                    info["current_recall"] = float(val)
                except ValueError:
                    pass

        elif "Drift" in name:
            info["trigger_reason"] = "drift_alert"
            val = alert.get("annotations", {}).get("value", "")
            if val:
                try:
                    info["drift_score"] = float(val)
                except ValueError:
                    pass

        elif "Performance" in name or "API" in name:
            info["trigger_reason"] = "performance_degradation"

    return info


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/alert", methods=["POST"])
def receive_alert():
    payload = request.json
    if not payload:
        return jsonify({"error": "No payload"}), 400

    alert_info = extract_alert_info(payload)
    logger.info(f"Received alert: {alert_info}")

    # Build GitHub Actions inputs
    inputs = {
        "trigger_reason": alert_info["trigger_reason"],
    }
    if alert_info["current_recall"] is not None:
        inputs["current_recall"] = str(alert_info["current_recall"])
    if alert_info["drift_score"] is not None:
        inputs["drift_score"] = str(alert_info["drift_score"])

    github_payload = {
        "ref": GITHUB_REF,
        "inputs": inputs,
    }

    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    try:
        resp = requests.post(GITHUB_API, json=github_payload, headers=headers, timeout=10)
        if resp.status_code == 204:
            logger.info(f"✅ GitHub Actions workflow triggered: {inputs['trigger_reason']}")
            return jsonify({"triggered": True, "reason": inputs["trigger_reason"]}), 200
        else:
            logger.error(f"GitHub API error: {resp.status_code} {resp.text}")
            return jsonify({"triggered": False, "error": resp.text}), 500
    except Exception as e:
        logger.error(f"Failed to trigger workflow: {e}")
        return jsonify({"triggered": False, "error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
